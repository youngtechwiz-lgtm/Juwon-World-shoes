import React from 'react';
import '../styles/FilterSection.css';

const FilterSection = ({ activeCategory, setActiveCategory }) => {
  const categories = [
    'All',
    'Sneakers',
    'Running Shoes',
    'Casual Shoes',
    'Corporate Shoes',
    'Boots',
    'Sandals',
    'Slides',
    'School Shoes'
  ];

  return (
    <div className="filter-section">
      <div className="filter-container">
        {categories.map((category) => (
          <button
            key={category}
            className={`filter-btn ${activeCategory === category ? 'active' : ''}`}
            onClick={() => setActiveCategory(category)}
          >
            {category}
          </button>
        ))}
      </div>
    </div>
  );
};

export default FilterSection;
