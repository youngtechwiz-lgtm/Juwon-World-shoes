
import { Link } from 'react-router-dom';
import '../styles/footer.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="footer-container container">

        {/* Column 1: Brand Info */}
        <div className="footer-col brand-col">
          <Link to="/" className="footer-logo">
            JUWON<span className="logo-accent">WORLD</span>
          </Link>
          <p className="brand-desc">
            Your premium online footwear showcase. Discover elite quality across our specialized collections and order directly via WhatsApp or phone.
          </p>
        </div>

        {/* Column 2: Quick Links */}
        <div className="footer-col">
          <h3>Quick Links</h3>
          <ul className="footer-links">
            <li><Link to="/">Home</Link></li>
            <li><Link to="/about">About Us</Link></li>
            <li><Link to="/products">All Products</Link></li>
            <li><Link to="/gallery">Gallery</Link></li>
            <li><Link to="/faq">FAQ</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </div>

        {/* Column 3: Categories */}
        <div className="footer-col">
          <h3>Categories</h3>
          <ul className="footer-links">
            <li><Link to="/Product?category=Sneakers">Sneakers</Link></li>
            <li><Link to="/Product?category=Running">Running Shoes</Link></li>
            <li><Link to="/Product?category=Casual">Casual Shoes</Link></li>
            <li><Link to="/Product?category=Corporate">Corporate Shoes</Link></li>
            <li><Link to="/Product?category=Boots">Boots & Sandals</Link></li>
          </ul>
        </div>

        {/* Column 4: Contact & Purchase Info */}
        <div className="footer-col contact-col">
          <h3>Direct Ordering</h3>
          <p>This is a product showcase site. To purchase, reach out directly:</p>
          <ul className="contact-info">
            <li><strong>WhatsApp:</strong>08058393911</li>
            <li><strong>Phone:</strong> 08058393911</li>
            <li><strong>Email:</strong> taiwojuwon599@gmail.com</li>
          </ul>
        </div>

      </div>

      {/* Bottom Bar */}
      <div className="footer-bottom">
        <div className="container bottom-content">
          <p>&copy; {currentYear} Shoe Store Showcase. All Rights Reserved.</p>
          <p className="tagline">Premium. Clean. Minimal.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;