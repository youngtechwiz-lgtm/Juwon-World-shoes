import React from 'react';
import { FaGem, FaSlidersH, FaHandshake, FaBullhorn } from 'react-icons/fa';
import '../styles/MissionSection.css';

const MissionSection = () => {
  const missions = [
    {
      icon: <FaGem />,
      title: "Uncompromising Quality",
      description: "We source only premium grade leathers, technical knits, and resilient outsoles to ensure every pair stands the test of time."
    },
    {
      icon: <FaSlidersH />,
      title: "Engineered Comfort",
      description: "Style shouldn't hurt. Our collection prioritizes ergonomic insoles and lightweight shock absorption for all-day comfort."
    },
    {
      icon: <FaHandshake />,
      title: "Direct Commitment",
      description: "We work directly with shoe enthusiasts. No middleware, no automated chatbots—just direct, personalized purchasing support."
    },
    {
      icon: <FaBullhorn />,
      title: "Trendsetting Curation",
      description: "From classic corporate formals to bold street retro sneakers, we curate styles that elevate your look in any setting."
    }
  ];

  return (
    <section className="mission-section">
      <div className="container">
        <div className="mission-header">
          <span className="section-subtitle">Our Purpose</span>
          <h2 className="section-title text-light">Guided by Core Values</h2>
          <p className="mission-header-desc">
            We are driven by a simple mission: to empower your journey by offering shoes that combine elite craftsmanship with everyday accessibility.
          </p>
        </div>

        <div className="mission-grid">
          {missions.map((item, idx) => (
            <div className="mission-card" key={idx}>
              <div className="mission-icon">{item.icon}</div>
              <h3 className="mission-card-title">{item.title}</h3>
              <p className="mission-card-desc">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default MissionSection;
