
import '../styles/Hero.css';

const Hero = () => {
  return (
    <section className="hero-section">
      <div className="hero-content">
        <span className="hero-badge">New 2026 Collection</span>
        <h1>Step Into Premium Comfort</h1>
        <p>Discover our curated collection of high-quality footwear built for style, performance, and everyday durability.</p>
        <a href="#featured" className="btn-primary">Explore Showcase</a>
      </div>
    </section>
  );
};

export default Hero;