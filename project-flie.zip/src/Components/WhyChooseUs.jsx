import React from 'react';
import { FaShieldAlt, FaWhatsapp, FaTruck, FaRedo } from 'react-icons/fa';
import '../styles/WhyChooseUs.css';

const WhyChooseUs = () => {
  const reasons = [
    {
      icon: <FaShieldAlt />,
      title: "Vetted Premium Quality",
      desc: "Every pair of shoes is hand-selected and inspected for durability, high-grade leather/knit materials, and comfort."
    },
    {
      icon: <FaWhatsapp />,
      title: "Direct Ordering Channels",
      desc: "Connect directly with our support on WhatsApp. Ask questions, select sizes, and finalize purchases with a real human."
    },
    {
      icon: <FaTruck />,
      title: "Rapid Local Shipping",
      desc: "Fast, reliable local logistics to deliver your new favorite pairs straight to your doorstep without delays."
    },
    {
      icon: <FaRedo />,
      title: "Hassle-Free Sizing Exchange",
      desc: "Unsure about size? We support easy size exchanges if you contact us within 48 hours of delivery."
    }
  ];

  return (
    <section className="why-choose-us container">
      <div className="section-header">
        <span className="section-pretitle">Our Edge</span>
        <h2>Why Shoe Store Showcase?</h2>
        <p>We combine digital visual excellence with personal, offline ordering convenience</p>
      </div>

      <div className="wcu-grid">
        {reasons.map((reason, idx) => (
          <div className="wcu-card" key={idx}>
            <div className="wcu-icon-wrapper">{reason.icon}</div>
            <h3 className="wcu-card-title">{reason.title}</h3>
            <p className="wcu-card-desc">{reason.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default WhyChooseUs;
