import React from 'react';
import ProductCard from './ProductCard';
import '../styles/ProductGrid.css';

const ProductGrid = ({ shoes }) => {
  if (shoes.length === 0) {
    return (
      <div className="no-products-found">
        <h3>No products found</h3>
        <p>Try refining your search query or choosing another category filter.</p>
      </div>
    );
  }

  return (
    <div className="product-grid-container">
      <div className="catalog-products-grid">
        {shoes.map((shoe) => (
          <ProductCard key={shoe.id} shoe={shoe} />
        ))}
      </div>
    </div>
  );
};

export default ProductGrid;
