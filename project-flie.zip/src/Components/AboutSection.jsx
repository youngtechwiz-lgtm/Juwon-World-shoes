import React from 'react';
import '../styles/AboutSection.css';

const AboutSection = () => {
  return (
    <section className="about-section">
      <div className="container about-grid">
        <div className="about-content">
          <span className="section-subtitle">Our Heritage</span>
          <h2 className="section-title">Redefining Modern Footwear</h2>
          <p className="about-text">
            Founded in 2026, SHOESTORE emerged from a singular vision: to bridge the gap between high-fashion streetwear and ultimate daily comfort. We believe that what you wear on your feet is the foundation of your confidence, style, and daily performance.
          </p>
          <p className="about-text">
            Every product in our showcase is handpicked and thoroughly vetted for material durability, design precision, and comfort. By operating as a direct showcase site, we cut out the complex retail markup, letting you order premium footwear directly through WhatsApp or phone.
          </p>
          <div className="about-features">
            <div className="feat-item">
              <span className="feat-num">100%</span>
              <span className="feat-label">Genuine Quality</span>
            </div>
            <div className="feat-item">
              <span className="feat-num">24/7</span>
              <span className="feat-label">Direct Support</span>
            </div>
            <div className="feat-item">
              <span className="feat-num">0%</span>
              <span className="feat-label">Hassle Delivery</span>
            </div>
          </div>
        </div>
        <div className="about-image-wrapper">
          <img 
            src="https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800&auto=format&fit=crop&q=80" 
            alt="Premium sneakers design" 
            className="about-image"
          />
          <div className="image-decorator"></div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
