import { Link } from 'react-router-dom';
import '../styles/ProductCard.css';
import { formatPrice } from '../helpers/formatCurrency';

const ProductCard = ({ shoe }) => {
  return (
    <Link to={`/product/${shoe.id}`} className="product-card-link">
      <div className="product-card">
        <img src={shoe.image} alt={shoe.name} className="product-image" />
        <h3 className="product-title">{shoe.name}</h3>
        <p className="product-price">{formatPrice(shoe.price)}</p>
      </div>
    </Link>
  );
};

export default ProductCard;