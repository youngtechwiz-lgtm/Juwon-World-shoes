
import React from 'react';
import '../styles/ProductsCard.css';

const ProductCard = ({ product }) => {
  // Generates a custom message link for offline purchasing via WhatsApp

  return (
    <div className="product-card">
      <div className="product-image-wrapper">
        <img src={product.image} alt={product.name} className="product-card-image" />
        <span className="product-badge">{product.category}</span>
      </div>
      <div className="product-card-info">
        <h3>{product.name}</h3>
        <p className="product-card-desc">{product.description}</p>
        <div className="product-card-footer">
          <span className="product-card-price">${product.price.toFixed(2)}</span>
          <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="order-btn">
            Order Now 📲
          </a>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;