import React from 'react';
import { FaStar, FaQuoteLeft } from 'react-icons/fa';
import '../styles/Testimonials.css';

const Testimonials = () => {
  const reviews = [
    {
      name: "Marcus Sterling",
      model: "Apex Neon Runner",
      review: "Absolutely outstanding performance. The sole has this incredible cushioning bounce, and they look stunning on and off the running track. Ordering via WhatsApp was quick and simple.",
      stars: 5
    },
    {
      name: "Amina Yusuf",
      model: "Vanguard Knit Sneaker",
      review: "These are so lightweight, it honestly feels like walking on clouds. Sizing exchange was handled instantly when I asked to swap from a 39 to a 40. Recommended 100%!",
      stars: 5
    },
    {
      name: "Daniel Alvarez",
      model: "Classic Leather Brogue",
      review: "Excellent craftsmanship. The stitching on these Brogues is perfect, and the calf leather feels extremely premium. Great addition to my corporate wardrobe.",
      stars: 5
    }
  ];

  return (
    <section className="testimonials-section">
      <div className="container">
        <div className="section-header text-center">
          <span className="section-pretitle">Feedbacks</span>
          <h2 className="text-light">Loved by Shoe Enthusiasts</h2>
          <p className="text-muted">Hear from our clients about their direct purchasing experience</p>
        </div>

        <div className="testimonials-grid">
          {reviews.map((item, idx) => (
            <div className="testimonial-card" key={idx}>
              <div className="quote-icon"><FaQuoteLeft /></div>
              
              <div className="stars-row">
                {[...Array(item.stars)].map((_, i) => (
                  <FaStar key={i} className="star-filled" />
                ))}
              </div>

              <p className="testimonial-text">"{item.review}"</p>

              <div className="testimonial-user">
                <h4 className="user-name">{item.name}</h4>
                <span className="purchased-model">Purchased: {item.model}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
