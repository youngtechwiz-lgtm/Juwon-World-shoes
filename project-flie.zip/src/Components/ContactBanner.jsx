import React from 'react';
import '../styles/ContactBanner.css';

const ContactBanner = () => {
  return (
    <section className="contact-banner-section">
      <div className="banner-container container">
        <h2>Found a pair you love?</h2>
        <p>We handle orders directly via WhatsApp or Phone call. Quick, personalized, offline purchasing.</p>
        {/* Updated line: Set directly to your phone's endpoint channel */}
        <a href="https://wa.me/2348058393911" target="_blank" rel="noopener noreferrer" className="btn-whatsapp">
          Inquire Over WhatsApp
        </a>
      </div>
    </section>
  );
};

export default ContactBanner;