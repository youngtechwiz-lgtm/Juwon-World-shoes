
import '../styles/Categories.css';
import { categoriesList } from '../Data/categories';

const Categories = () => {
  return (
    <section className="categories-section container">
      <div className="section-header">
        <h2>Browse Categories</h2>
        <p>Find the exact fit for your lifestyle</p>
      </div>
      <div className="categories-grid">
        {categoriesList.map((category) => (
          <div key={category.id} className="category-card" style={{ backgroundImage: `linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.6)), url(${category.image})` }}>
            <h3>{category.name}</h3>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Categories;