
import '../styles/FeaturedProducts.css';
import ProductCard from './ProductCard';
import { featuredProductsList } from '../Data/featuredProductsList';

const FeaturedProducts = () => {
  return (
    <section id="featured" className="featured-section container">
      <div className="section-header">
        <h2>Featured Products</h2>
        <p>Handpicked elite items from our showcase</p>
      </div>
      <div className="products-grid">
        {featuredProductsList.map((shoe) => (
          <ProductCard key={shoe.id} shoe={shoe} />
        ))}
      </div>
    </section>
  );
};

export default FeaturedProducts;