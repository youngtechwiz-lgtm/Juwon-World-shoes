import React from 'react';
import '../styles/VisionSection.css';

const VisionSection = () => {
  return (
    <section className="vision-section">
      <div className="container vision-container">
        <div className="vision-grid-layout">
          
          {/* Left Column: Visual card or banner details */}
          <div className="vision-visual">
            <div className="vision-overlay-box">
              <span className="overlay-tag">Our Vision</span>
              <h3>To become the ultimate footwear destination for styling and comfort.</h3>
              <p>We aim to expand our curated collections while retaining our commitment to direct, custom service for every single shopper.</p>
            </div>
            <img 
              src="https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800&auto=format&fit=crop&q=80" 
              alt="Premium leather shoes" 
              className="vision-bg-img"
            />
          </div>

          {/* Right Column: Key vision pillars and stats */}
          <div className="vision-content">
            <span className="section-subtitle">Future Roadmap</span>
            <h2 className="section-title">Elevating the Path Ahead</h2>
            <p className="vision-text">
              We look forward to introducing sustainable material lines, custom shoe-fit advisors, and direct-to-door showcase vans where you can try on shoes before completing your offline order.
            </p>

            <div className="vision-pillars">
              <div className="pillar-item">
                <h4>01 / Sustainable Curation</h4>
                <p>Incorporating eco-friendly materials and carbon-reduced supply lines in our next collections.</p>
              </div>
              <div className="pillar-item">
                <h4>02 / Personalized Fit Advisors</h4>
                <p>Offering sizing support matching unique foot shapes for custom style and zero stress.</p>
              </div>
              <div className="pillar-item">
                <h4>03 / Seamless Community Hub</h4>
                <p>Building local sneaker clubs and customer forums to share designs, care tips, and exclusive early product drop reviews.</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default VisionSection;
