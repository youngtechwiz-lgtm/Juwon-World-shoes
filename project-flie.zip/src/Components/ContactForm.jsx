import React, { useState } from 'react';
import { FaPaperPlane, FaWhatsapp } from 'react-icons/fa';
import '../styles/ContactForm.css';

const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    shoeModel: '',
    message: ''
  });
  const [isCopied, setIsCopied] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleWhatsAppRedirect = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.message) {
      alert("Please fill in your Name and Message to format the WhatsApp inquiry.");
      return;
    }
    const messageText = `Hi JUWONWORLD support,\n\nName: ${formData.name}\nEmail: ${formData.email || 'N/A'}\nInterested Model: ${formData.shoeModel || 'General Inquiry'}\n\nMessage: ${formData.message}`;
    const encodedText = encodeURIComponent(messageText);
    // Updated line: Formatted for global WhatsApp URL routing standard
    window.open(`https://wa.me/2348058393911?text=${encodedText}`, '_blank');
  };

  const handleCopyInquiry = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.message) {
      alert("Please fill in your Name and Message to copy.");
      return;
    }
    const messageText = `Name: ${formData.name}\nEmail: ${formData.email || 'N/A'}\nInterested Model: ${formData.shoeModel || 'General Inquiry'}\n\nMessage: ${formData.message}`;
    navigator.clipboard.writeText(messageText);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <form className="contact-form">
      <div className="form-group">
        <label htmlFor="name">Your Name *</label>
        <input
          type="text"
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          required
          placeholder="e.g. John Doe"
        />
      </div>

      <div className="form-group">
        <label htmlFor="email">Email Address</label>
        <input
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          placeholder="e.g. john@example.com"
        />
      </div>

      <div className="form-group">
        <label htmlFor="shoeModel">Interested Shoe Model (Optional)</label>
        <input
          type="text"
          id="shoeModel"
          name="shoeModel"
          value={formData.shoeModel}
          onChange={handleChange}
          placeholder="e.g. Apex Neon Runner"
        />
      </div>

      <div className="form-group">
        <label htmlFor="message">Your Inquiry Message *</label>
        <textarea
          id="message"
          name="message"
          rows="5"
          value={formData.message}
          onChange={handleChange}
          required
          placeholder="What details, sizing, or delivery questions do you have?"
        ></textarea>
      </div>

      <div className="form-actions">
        <button 
          onClick={handleWhatsAppRedirect} 
          className="btn-form-whatsapp"
        >
          <FaWhatsapp /> Send via WhatsApp
        </button>
        <button 
          onClick={handleCopyInquiry} 
          className="btn-form-secondary"
        >
          <FaPaperPlane /> {isCopied ? "Copied to Clipboard!" : "Copy Inquiry Details"}
        </button>
      </div>
    </form>
  );
};

export default ContactForm;