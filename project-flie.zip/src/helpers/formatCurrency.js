
export const formatPrice = (price) => {
  return new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    minimumFractionDigits: 0, // Option: Removes the kobo decimals (.00) since Naira transactions rarely use them now
    maximumFractionDigits: 0,
  }).format(price);
};