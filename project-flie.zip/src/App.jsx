import Home from "./Pages/Home"
import About from "./Pages/About"
import Navbar from './Components/Navbar';
import Footer from './Components/footer';
import { Routes, Route } from 'react-router-dom';
import Gallery from "./Pages/Gallery";
import Contact from "./Pages/Contact";
import FAQ from "./Pages/FAQ";
import Product from "./Pages/Product";


function App() {
  return (
    <>
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/Gallery" element={<Gallery />} />
          <Route path="/Contact" element={<Contact />} />
          <Route path="/FAQ" element={<FAQ />} />
          <Route path="/Product" element={<Product />} />
          {/* Future routes like /products, /contact will be registered here */}
        </Routes>
      </main>
      <Footer />
    </>
  )
}

export default App

