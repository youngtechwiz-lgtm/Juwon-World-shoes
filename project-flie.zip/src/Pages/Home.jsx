
import '../styles/Home.css';

// Sub-components/sections for Home
import Hero from '../Components/Hero';
import FeaturedProducts from '../Components/FeaturedProducts';
import Categories from '../Components/Categories';
import WhyChooseUs from '../Components/WhyChooseUs';
import Testimonials from '../Components/Testimonials';
import ContactBanner from '../Components/ContactBanner';

const Home = () => {
  return (
    <div className="home-page">
      <Hero />
      <FeaturedProducts />
      <Categories />
      <WhyChooseUs />
      <Testimonials />
      <ContactBanner />
    </div>
  );
};

export default Home;