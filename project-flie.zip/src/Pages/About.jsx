import React, { useEffect } from 'react';
import AboutSection from '../Components/AboutSection';
import MissionSection from '../Components/MissionSection';
import VisionSection from '../Components/VisionSection';
import '../styles/About.css';

const About = () => {
  // Scroll to top when navigation occurs to this page
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="about-page">
      {/* Header Banner */}
      <header className="about-header-banner">
        <div className="container banner-inner">
          <span className="banner-badge">Our Story</span>
          <h1 className="banner-title">Crafting Premium Footwear Experiences</h1>
          <p className="banner-subtitle">
            Learn about our dedication to uncompromising quality, design ergonomics, and why we build shoes that feel like home.
          </p>
        </div>
      </header>

      {/* Embedded Sub-sections */}
      <AboutSection />
      <MissionSection />
      <VisionSection />
    </div>
  );
};

export default About;
