import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { FaWhatsapp, FaArrowLeft, FaShieldAlt, FaTruck } from 'react-icons/fa';
import { productsList } from '../Data/productsData';
import '../styles/ProductDetails.css';

const ProductDetails = () => {
  const { id } = useParams();
  const shoe = productsList.find((item) => item.id === id);

  const [selectedSize, setSelectedSize] = useState('');
  const sizes = ['39', '40', '41', '42', '43', '44', '45'];

  // Scroll to top on load
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!shoe) {
    return (
      <div className="container product-not-found-page">
        <h2>Product Not Found</h2>
        <p>Sorry, the footwear model you are looking for does not exist or has been removed from our showcase.</p>
        <Link to="/products" className="btn-primary">Return to Catalog</Link>
      </div>
    );
  }

  // Pre-fill message for direct WhatsApp ordering (No prices included)
  const whatsappNumber = '1234567890'; // Mock seller WhatsApp number
  const messageText = `Hi, I am interested in inquiring about the "${shoe.name}" (Model ID: ${shoe.id}) from your website.${selectedSize ? ` Size: ${selectedSize}.` : ''} Is it currently available?`;
  const encodedMessage = encodeURIComponent(messageText);
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;

  return (
    <div className="product-details-page-container">
      <div className="container">
        {/* Back Link */}
        <Link to="/products" className="back-link">
          <FaArrowLeft /> Back to Showcase
        </Link>

        {/* Details Grid */}
        <div className="details-grid">
          {/* Image Panel */}
          <div className="details-image-panel">
            <img src={shoe.image} alt={shoe.name} className="details-image" />
          </div>

          {/* Info Panel */}
          <div className="details-info-panel">
            <span className="details-category">{shoe.category}</span>
            <h1 className="details-title">{shoe.name}</h1>

            {/* 💡 Note: Price element completely removed from here */}

            <div className="details-description">
              <h3>Description</h3>
              <p>{shoe.description}</p>
            </div>

            {/* Sizing Section */}
            <div className="details-sizing">
              <h3>Select Size (EU)</h3>
              <div className="size-chips-grid">
                {sizes.map((size) => (
                  <button
                    key={size}
                    className={`size-chip-btn ${selectedSize === size ? 'active' : ''}`}
                    onClick={() => setSelectedSize(size)}
                  >
                    {size}
                  </button>
                ))}
              </div>
              {selectedSize && (
                <p className="selected-size-feedback">
                  Selected Size: <strong>{selectedSize}</strong>
                </p>
              )}
            </div>

            {/* WhatsApp Purchase CTA */}
            <div className="details-purchase-cta">
              <a 
                href={whatsappUrl} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="btn-whatsapp-order"
              >
                <FaWhatsapp className="cta-icon" /> Inquire & Order via WhatsApp
              </a>
              <p className="purchase-note">
                Orders are processed offline. Sizing, availability, and delivery details will be confirmed directly with you on WhatsApp.
              </p>
            </div>

            {/* Fast Features */}
            <div className="details-mini-features">
              <div className="mini-feat">
                <FaShieldAlt className="mini-icon" />
                <div>
                  <strong>Genuine Product</strong>
                  <span>Hand-vetted premium materials</span>
                </div>
              </div>
              <div className="mini-feat">
                <FaTruck className="mini-icon" />
                <div>
                  <strong>Direct Delivery</strong>
                  <span>Quick local logistics options</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;