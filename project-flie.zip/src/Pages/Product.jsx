import React, { useState } from 'react';
// Import your master product data list
import { productsList } from '../Data/product'; 

// Import all your atomic layout components
import SearchBar from '../components/SearchBar';
import FilterSection from '../components/FilterSection';
import ProductGrid from '../components/ProductGrid';

// Import styling
import '../styles/Product.css';

const Product = () => {
  // 1. Centralize the state for search and category selections
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  // 2. Compute the filtered subset of shoes based on inputs
  const filteredShoes = productsList.filter((shoe) => {
    const matchesSearch = 
      shoe.name.toLowerCase().includes(query.toLowerCase()) || 
      (shoe.description && shoe.description.toLowerCase().includes(query.toLowerCase()));
      
    const matchesCategory = 
      activeCategory === 'All' || 
      shoe.category.toLowerCase() === activeCategory.toLowerCase();

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="products-page container">
      {/* Page Header */}
      <div className="products-header">
        <h1>Our Footwear Collection</h1>
        <p>Premium quality designed for modern lifestyle, work, and sports performance.</p>
      </div>

      {/* 3. Link the SearchBar component with state control props */}
      <SearchBar query={query} setQuery={setQuery} />

      {/* 4. Link the FilterSection component with category tracking props */}
      <FilterSection activeCategory={activeCategory} setActiveCategory={setActiveCategory} />

      {/* 5. Link the ProductGrid component by passing the filtered list results */}
      <ProductGrid shoes={filteredShoes} />
    </div>
  );
};

export default Product;