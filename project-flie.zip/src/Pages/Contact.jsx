import React, { useEffect } from 'react';
import { FaPhoneAlt, FaWhatsapp, FaEnvelope, FaMapMarkerAlt, FaClock } from 'react-icons/fa';
import ContactForm from '../Components/ContactForm';
import '../styles/Contact.css';

const Contact = () => {
  // Scroll to top on page enter
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="contact-page-container">
      {/* Header Banner */}
      <header className="contact-header">
        <div className="container">
          <span className="contact-badge">Reach Out</span>
          <h1>Contact Us</h1>
          <p>Have questions about sizing, customization, or shipping? Get in touch directly via form, phone, or WhatsApp.</p>
        </div>
      </header>

      {/* Main Contact Grid */}
      <section className="contact-section container">
        <div className="contact-grid-layout">
          
          {/* Info Details Panel */}
          <div className="contact-info-panel">
            <h2>Direct Inquiry Channels</h2>
            <p className="info-intro">
              We process product sales offline. Reach out directly and our team will check availability and organize shipping routes for you.
            </p>

            <div className="info-list">
              <div className="info-card">
                <FaWhatsapp className="info-icon icon-wa" />
                <div className="info-texts">
                  <strong>WhatsApp Chat</strong>
                  <a href="https://wa.me/08058393911" target="_blank" rel="noopener noreferrer">+2348058393911</a>
                  <span>Fast response (Mon - Sat)</span>
                </div>
              </div>

              <div className="info-card">
                <FaPhoneAlt className="info-icon" />
                <div className="info-texts">
                  <strong>Phone Line</strong>
                  <a href="tel:+2348058393911">+2348058393911</a>
                  <span>Call to ask size availability</span>
                </div>
              </div>

              <div className="info-card">
                <FaEnvelope className="info-icon" />
                <div className="info-texts">
                  <strong>Support Email</strong>
                  <a href="mailto:taiwojuwon599@gmail.com">taiwojuwon599@gmail.com</a>
                  <span>Replied within 24 hours</span>
                </div>
              </div>

              <div className="info-card">
                <FaMapMarkerAlt className="info-icon" />
                <div className="info-texts">
                  <strong>Showroom Showroom</strong>
                  <span>Awoyaya, Ibeju-Lekki</span>
                  <span>Lagos.</span>
                </div>
              </div>

              <div className="info-card">
                <FaClock className="info-icon" />
                <div className="info-texts">
                  <strong>Showcase Working Hours</strong>
                  <span>Monday - Friday: 9:00 AM - 6:00 PM</span>
                  <span>Saturday: 10:00 AM - 4:00 PM</span>
                  <span>Sunday: Closed (Inquiries active on WA)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Form Panel */}
          <div className="contact-form-panel">
            <h2>Send a Showcase Inquiry</h2>
            <p className="form-intro">
              Fill in the form to package your order requirements. You can copy the template or send it directly on WhatsApp.
            </p>
            <ContactForm />
          </div>

        </div>
      </section>
    </div>
  );
};

export default Contact;
