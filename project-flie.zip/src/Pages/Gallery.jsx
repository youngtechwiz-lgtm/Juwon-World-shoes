import React, { useEffect } from 'react';
import '../styles/Gallery.css';

const Gallery = () => {
  const galleryItems = [
    {
      id: 1,
      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600',
      title: 'Neon Streetwear Focus',
      tag: 'Performance'
    },
    {
      id: 2,
      image: 'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=600',
      title: 'Retro High Top Details',
      tag: 'Lifestyle'
    },
    {
      id: 3,
      image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=600',
      title: 'Avant-garde Knit Silhouette',
      tag: 'Sneakers'
    },
    {
      id: 4,
      image: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=600',
      title: 'Artisanal Brogue Welt',
      tag: 'Corporate'
    },
    {
      id: 5,
      image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=600',
      title: 'Suede Textures Close-up',
      tag: 'Casual'
    },
    {
      id: 6,
      image: 'https://images.unsplash.com/photo-1520639888713-7851133b1ed0?w=600',
      title: 'Rugged Outsole Engineering',
      tag: 'Boots'
    },
    {
      id: 7,
      image: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=600',
      title: 'Endurance Trail Running',
      tag: 'Athletic'
    },
    {
      id: 8,
      image: 'https://images.unsplash.com/photo-1614252329306-6466904fa2e8?w=600',
      title: 'Polished Monkstrap Detail',
      tag: 'Formal'
    }
  ];

  // Scroll to top on page enter
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="gallery-page-container">
      {/* Header Banner */}
      <header className="gallery-header">
        <div className="container">
          <span className="gallery-badge">Lookbook</span>
          <h1>Editorial Gallery</h1>
          <p>A closer look at the textures, craftsmanship, and styles that define the Shoe Store experience.</p>
        </div>
      </header>

      {/* Gallery Grid */}
      <section className="gallery-section container">
        <div className="gallery-grid-layout">
          {galleryItems.map((item) => (
            <div className="gallery-item-card" key={item.id}>
              <img src={item.image} alt={item.title} className="gallery-img" />
              <div className="gallery-info-overlay">
                <span className="gallery-tag">{item.tag}</span>
                <h3 className="gallery-title">{item.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Gallery;
