import React, { useState, useEffect } from 'react';
import { FaChevronDown } from 'react-icons/fa';
import '../styles/FAQ.css';

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(null);

  const faqs = [
    {
      q: "How does the direct ordering process work?",
      a: "Since this is a showcase website, we do not require credit cards or complex registrations. Simply browse our footwear, click on the model you like, select your desired EU size, and click the 'Inquire & Order via WhatsApp' button. You will be connected directly to our support representative to confirm availability and finalize delivery."
    },
    {
      q: "What payment methods do you accept?",
      a: "We support direct bank transfers, mobile money deposits, and cash on delivery (depending on your specific shipping address). Details will be shared directly with you on WhatsApp once your order is confirmed."
    },
    {
      q: "How long does shipping take?",
      a: "Standard local shipping takes 1 to 3 business days. Same-day or next-day expedited shipping is available in selected metro areas. Shipping fees and times will be detailed when we coordinate your dropoff."
    },
    {
      q: "What is your sizing exchange policy?",
      a: "We want your shoes to fit perfectly! If you receive your pair and find the size is not ideal, contact us via WhatsApp within 48 hours. As long as the shoes are unworn, clean, and in their original packaging, we will arrange a quick swap for your desired size."
    },
    {
      q: "Are the shoes in the showcase genuine?",
      a: "Yes, every pair in our showcase is 100% genuine and sourced from vetted manufacturer lines to guarantee premium grade materials, precise stitching, and lasting comfort."
    }
  ];

  const toggleFAQ = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  // Scroll to top on load
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="faq-page-container">
      {/* Header Banner */}
      <header className="faq-header">
        <div className="container">
          <span className="faq-badge">Support</span>
          <h1>Frequently Asked Questions</h1>
          <p>Got questions about our direct showcase ordering or footwear sizing? We have answers.</p>
        </div>
      </header>

      {/* FAQ Accordions */}
      <section className="faq-section container">
        <div className="faq-list">
          {faqs.map((faq, idx) => (
            <div 
              key={idx} 
              className={`faq-item ${openIndex === idx ? 'open' : ''}`}
            >
              <button 
                className="faq-question-btn" 
                onClick={() => toggleFAQ(idx)}
                aria-expanded={openIndex === idx}
              >
                <span>{faq.q}</span>
                <FaChevronDown className="arrow-icon" />
              </button>
              <div className="faq-answer">
                <p>{faq.a}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default FAQ;
