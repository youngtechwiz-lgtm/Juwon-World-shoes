// Base Imports
import Boot1 from '../assets/Boot1.jpg';
import Boot4 from '../assets/Boot4.jpg';
import Boot5 from '../assets/Boot5.jpg';
import Jordan1 from '../assets/jordans (1).jpg';
import Jordan2 from '../assets/jordans (2).jpg';
import Jordan3 from '../assets/jordans (3).jpg';

// First Batch Upload Imports
import AdidasSuperstarBrown from '../assets/IMG-20260714-WA0129.jpg';
import NikeAirForcePurple from '../assets/IMG-20260714-WA0130.jpg';
import NewBalance740Blue from '../assets/IMG-20260714-WA0131.jpg';
import NewBalance740Collage from '../assets/IMG-20260714-WA0132.jpg';
import AsicsGelKayanoSilver from '../assets/IMG-20260714-WA0133.jpg';
import AsicsGelKayanoCream from '../assets/IMG-20260714-WA0134.jpg';
import AsicsGelKayanoChair from '../assets/IMG-20260714-WA0135.jpg';
import TimberlandGoldGrid from '../assets/IMG-20260714-WA0136.jpg';
import TimberlandGoldSingle from '../assets/IMG-20260714-WA0137.jpg';

// Second Batch Upload Imports
import AsicsBlackSilver from '../assets/IMG-20260714-WA0170.jpg';
import NikeVomeroSilver from '../assets/IMG-20260714-WA0171.jpg';
import NikeVomeroBlue from '../assets/IMG-20260714-WA0172.jpg';
import NewBalance1906Green from '../assets/IMG-20260714-WA0173.jpg';
import NewBalance1906Silver from '../assets/IMG-20260714-WA0174.jpg';
import AsicsGelNimbusCream from '../assets/IMG-20260714-WA0176.jpg';
import CampusRetroBlack from '../assets/IMG-20260714-WA0177.jpg';
import CampusRetroPink from '../assets/IMG-20260714-WA0178.jpg';
import BirkenstockBostonTaupe from '../assets/IMG-20260714-WA0179.jpg';
import BirkenstockBostonBrown from '../assets/IMG-20260714-WA0180.jpg';

export const productsList = [
  {
    id: 'p1',
    name: 'Apex Neon Runner',
    category: 'Running Shoes',
    price: 195000,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500',
    description: 'Ultra-lightweight premium running shoes with reactive foam sole technology.'
  },
  {
    id: 'p2',
    name: 'Urban Street Retro',
    category: 'Sneakers',
    price: 142500,
    image: 'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=500',
    description: 'Classic canvas street design built for daily premium casual comfort.'
  },
  {
    id: 'p3',
    name: 'Classic Leather Brogue',
    category: 'Corporate Shoes',
    price: 217500,
    image: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=500',
    description: 'Handcrafted genuine leather formal shoes optimized for business environments.'
  },
  {
    id: 'p4',
    name: 'Timber Land (Black)',
    category: 'Boots',
    price: 217500,
    image: Boot1,
    description: 'Handcrafted genuine leather rugged boots optimized for all-weather conditions.'
  },
  {
    id: 'p5',
    name: 'Timber Land (Gray)',
    category: 'Boots',
    price: 217500,
    image: Boot4,
    description: 'Premium gray nubuck leather boots built with durable tracked outsoles.'
  },
  {
    id: 'p6',
    name: 'Timber Land (Brown)',
    category: 'Boots',
    price: 217500,
    image: Boot5,
    description: 'Classic brown outdoor utility boots presenting signature heavy-duty styling.'
  },
  {
    id: 'p7',
    name: 'Jordan Retro High',
    category: 'Sneakers',
    price: 217500,
    image: Jordan1,
    description: 'Iconic basketball high-top sneakers offering ultimate ankle support and heritage charm.'
  },
  {
    id: 'p8',
    name: 'Jordan Retro Mid',
    category: 'Sneakers',
    price: 217500,
    image: Jordan2,
    description: 'Versatile mid-cut court lifestyle sneakers styled for modern street fashion.'
  },
  {
    id: 'p9',
    name: 'Jordan Retro Low',
    category: 'Sneakers',
    price: 217500,
    image: Jordan3,
    description: 'Low-profile athletic retro sneakers presenting a sleek silhouette for daily wear.'
  },
  {
    id: 'p10',
    name: 'Adidas Superstar (Suede Brown)',
    category: 'Sneakers',
    price: 165000,
    image: AdidasSuperstarBrown,
    description: 'Classic shell-toe sneakers upgraded with a premium textured brown suede upper and black stripes.'
  },
  {
    id: 'p11',
    name: 'Nike Air Force 1 (Monochrome Purple)',
    category: 'Sneakers',
    price: 180000,
    image: NikeAirForcePurple,
    description: 'Bold all-purple colorway variant of the timeless low-top street icon, featuring matching custom insoles.'
  },
  {
    id: 'p12',
    name: 'New Balance 740 (White/Blue Metallic)',
    category: 'Running Shoes',
    price: 195000,
    image: NewBalance740Blue,
    description: 'Retro technical running shoe with breathable mesh panels and supportive metallic silver overlays.'
  },
  {
    id: 'p13',
    name: 'New Balance 740 (Showcase Variant)',
    category: 'Running Shoes',
    price: 195000,
    image: NewBalance740Collage,
    description: 'Premium edition athletic running shoe built for high-mileage road performance and retro style aesthetics.'
  },
  {
    id: 'p14',
    name: 'Asics Gel-Kayano 14 (Silver Metallic)',
    category: 'Running Shoes',
    price: 225000,
    image: AsicsGelKayanoSilver,
    description: 'Late 2000s running style silhouette updated with modern gel cushioning technology for impact absorption.'
  },
  {
    id: 'p15',
    name: 'Asics Gel-Kayano 14 (Cream/Gold)',
    category: 'Running Shoes',
    price: 232500,
    image: AsicsGelKayanoCream,
    description: 'Warm cream-toned running silhouette featuring breathable knit mesh structural components.'
  },
  {
    id: 'p16',
    name: 'Asics Gel-Kayano 14 (Studio Edition)',
    category: 'Running Shoes',
    price: 225000,
    image: AsicsGelKayanoChair,
    description: 'Lightweight structural training sneaker optimized for multi-surface running performance.'
  },
  {
    id: 'p17',
    name: 'Timberland 6-Inch Premium (Classic Gold)',
    category: 'Boots',
    price: 297000,
    image: TimberlandGoldGrid,
    description: 'The authentic original waterproof work boot crafted from gold nubuck leather with comfortable padded collars.'
  },
  {
    id: 'p18',
    name: 'Timberland Premium (Single Pack)',
    category: 'Boots',
    price: 297000,
    image: TimberlandGoldSingle,
    description: 'Heavy-duty rugged footwear option featuring secure lace hooks and oil-resistant seam-sealed construction.'
  },
  {
    id: 'p19',
    name: 'Asics Gel-Kayano 14 (Stealth Black/Silver)',
    category: 'Running Shoes',
    price: 225000,
    image: AsicsBlackSilver,
    description: 'Dark technical runner combining deep matte black mesh foundations with high-visibility reflective detailing.'
  },
  {
    id: 'p20',
    name: 'Nike Zoom Vomero 5 (Metallic Platinum)',
    category: 'Sandals',
    price: 240000,
    image: NikeVomeroSilver,
    description: 'Complex layered Y2K running aesthetic incorporating structural plastic cages and vintage mesh textures.'
  },
  {
    id: 'p21',
    name: 'Nike Zoom Vomero 5 (Electric Blue)',
    category: 'Sandals',
    price: 240000,
    image: NikeVomeroBlue,
    description: 'Eye-catching variant featuring striking vibrant blue paneling accents woven along a balanced athletic base.'
  },
  {
    id: 'p22',
    name: 'New Balance 1906R (Forest Green Edition)',
    category: 'Running Shoes',
    price: 232500,
    image: NewBalance1906Green,
    description: 'N-ergy shock-absorbing outsole equipped runner styled with tech-focused synthetic cages and deep forest accents.'
  },
  {
    id: 'p23',
    name: 'New Balance 1906R (Pure Chrome Silver)',
    category: 'Running Shoes',
    price: 232500,
    image: NewBalance1906Silver,
    description: 'High-shine cybernetic retro runner showcasing bright metallic web overlays for everyday modern lifestyle fashion.'
  },
  {
    id: 'p24',
    name: 'Asics Gel-Nimbus 9 (Cream/Mocha)',
    category: 'Running Shoes',
    price: 247500,
    image: AsicsGelNimbusCream,
    description: 'Premium lifestyle performance shoe layered with warm cream panels and distinctive gel cushioning windows.'
  },
  {
    id: 'p25',
    name: 'Adidas Campus 00s (Core Black)',
    category: 'Sneakers',
    price: 165000,
    image: CampusRetroBlack,
    description: 'Chunky skate-inspired transformation of a classic, showcasing fat laces and oversized contrast serrated stripes.'
  },
  {
    id: 'p26',
    name: 'Adidas Campus 00s (Pink Blossom)',
    category: 'Sneakers',
    price: 165000,
    image: CampusRetroPink,
    description: 'Playful pastel pink suede low-tops offering standard bold retro contours built for casual street outfitting.'
  },
  {
    id: 'p27',
    name: 'Birkenstock Boston Clog (Taupe Suede)',
    category: 'Slides',
    price: 240000,
    image: BirkenstockBostonTaupe,
    description: 'Timeless slip-on mules featuring ultra-soft genuine suede uppers and anatomically shaped cork footbeds.'
  },
  {
    id: 'p28',
    name: 'Birkenstock Boston Clog (Mink Brown)',
    category: 'Slides',
    price: 240000,
    image: BirkenstockBostonBrown,
    description: 'Deep brown variant showcasing adjustable metal buckle straps, prioritizing pure comfort and clean lounge utility.'
  }
];

export const allCategories = ['All', 'Sneakers', 'Running Shoes', 'Slides', 'Boots', 'Corporate Shoes'];