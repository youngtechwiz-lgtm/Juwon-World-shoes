
import NikeVomeroSilver from '../assets/IMG-20260714-WA0171.jpg';
import NikeVomeroBlue from '../assets/IMG-20260714-WA0172.jpg';
export const categoriesList = [
  { id: 1, name: 'Sneakers', image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?w=500' },
  { id: 2, name: 'Running Shoes', image: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=500' },
  { id: 3, name: 'Casual Shoes', image: 'https://images.unsplash.com/photo-1539185441755-769473a23570?w=500' },
  { id: 4, name: 'Corporate Shoes', image: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=500' },
  { id: 4, name: 'Sandals', image: NikeVomeroSilver }
];

