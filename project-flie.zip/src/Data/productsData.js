// High quality shoe catalog dataset
import Boot1 from '../assets/Boot1.jpg' 
export const productsList = [
  {
    id: 's1',
    name: 'Apex Neon Runner',
    category: 'Running Shoes',
    price: 129.99,
    description: 'Designed for professional athletes and daily joggers alike. Features breathable engineered mesh, reactive nitrogen-injected midsole foam, and an abrasion-resistant rubber grip outsole.',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 's2',
    name: 'Urban Street Retro',
    category: 'Sneakers',
    price: 95.00,
    description: 'A throwback classic refreshed for modern street styling. Built with full-grain leather panels, a supportive cupsole, and premium Ortholite cushioning for all-day comfort.',
    image: 'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 's3',
    name: 'Classic Leather Brogue',
    category: 'Corporate Shoes',
    price: 145.00,
    description: 'Refined style for executive presence. Handcrafted from premium calfskin leather, features meticulous brogue detailing, leather lining, and a durable welted sole structure.',
    image: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 's4',
    name: 'Summit Waterproof Boot',
    category: 'Boots',
    price: 180.00,
    description: 'Built to withstand rugged conditions. Features waterproof nubuck leather, seam-sealed construction, rustproof hardware, and a Vibram lugged outsole for supreme traction.',
    image: 'https://images.unsplash.com/photo-1520639888713-7851133b1ed0?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 's5',
    name: 'Nomad Leather Sandal',
    category: 'Sandals',
    price: 75.00,
    description: 'The ultimate warm-weather companion. Made with vegetable-tanned leather straps, an adjustable buckle, and a contoured cork-latex footbed that molds to your foot over time.',
    image: 'https://images.unsplash.com/photo-1486064016558-2fcfed77a22b?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 's6',
    name: 'Cloud Lounge Slide',
    category: 'Slides',
    price: 45.00,
    description: 'Unmatched comfort for casual strolls and indoor recovery. Features a single-piece EVA foam body, contoured arch support, and a non-slip textured footbed.',
    image: 'https://images.unsplash.com/photo-1603808033192-082d6919d3e1?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 's7',
    name: 'Academic Premium Oxford',
    category: 'School Shoes',
    price: 85.00,
    description: 'Durable and smart uniform footwear. Crafted with scuff-resistant coated leather, reinforced collar cushioning, and a non-marking vulcanized rubber outsole.',
    image: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 's8',
    name: 'Vanguard Knit Sneaker',
    category: 'Sneakers',
    price: 110.00,
    description: 'Ultralight, breathable, and styled for the future. Features a one-piece stretch knit upper, custom sock-fit collar, and responsive high-rebound cushioning.',
    image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 's9',
    name: 'Elite Carbon Racer',
    category: 'Running Shoes',
    price: 199.99,
    description: 'Engineered for speed records. Features a full-length carbon fiber propulsion plate, hyper-responsive PEBA mid-foam, and lightweight translucent mono-mesh upper.',
    image: 'https://images.unsplash.com/photo-1539185441755-769473a23570?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 's10',
    name: 'Chelsea Suede Boot',
    category: 'Boots',
    price: 160.00,
    description: 'Timeless sleek fashion. Made from water-resistant split suede leather, twin elastic side panels, front and back pull tabs, and a refined rubber outsole.',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 's11',
    name: 'City Walker Slip-on',
    category: 'Casual Shoes',
    price: 89.00,
    description: 'Easy wearing for everyday errands. Features soft washed-canvas uppers, elastic gore detailing for easy on-off, and a memory foam cushioned sockliner.',
    image: 'https://images.unsplash.com/photo-1560343090-f0409e92791a?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 's12',
    name: 'Prestige Double Monkstrap',
    category: 'Corporate Shoes',
    price: 155.00,
    description: 'Command attention in the boardroom. Designed with sleek polished hand-colored leather, brass buckle straps, premium leather lining, and stacked leather heels.',
    image: 'https://images.unsplash.com/photo-1614252329306-6466904fa2e8?w=600&auto=format&fit=crop&q=80'
  },

];
