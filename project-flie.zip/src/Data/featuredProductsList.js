export const featuredProductsList = [
  {
    id: 'f1',
    name: 'Apex Neon Runner',
    category: 'Running Shoes',
    price: 195000,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500'
  },
  {
    id: 'f2',
    name: 'Urban Street Retro',
    category: 'Sneakers',
    price: 142500,
    image: 'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=500'
  },
  {
    id: 'f3',
    name: 'Classic Leather Brogue',
    category: 'Corporate Shoes',
    price: 217500,
    image: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=500'
  }
];